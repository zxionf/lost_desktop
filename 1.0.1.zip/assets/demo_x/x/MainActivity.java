// package com.zyx.x;

// import android.content.Context;
// import android.os.Build;
// import android.os.Bundle;
// import android.view.View;
// import android.view.Window;
// import android.view.WindowManager;
// import com.badlogic.gdx.backends.android.AndroidApplication;
// import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
// //import androidx.multidex.MultiDex;

// public class MainActivity extends AndroidApplication {
	
	
//     @Override
//     public void onCreate(Bundle savedInstanceState) {
//         super.onCreate(savedInstanceState);
        
// 		//getWindow().addFlags(WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES);
//         //Window window = getWindow();
// //        // 设置页面全屏显示
// //        final View decorView = window.getDecorView();
// //        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
// //        setTheme(android.R.style.Theme_Holo_Light_NoActionBar_Fullscreen);
// //        
// //        setContentView(R.layout.activity_main);
        
//         //MyGdxGame n = new MyGdxGame();
//         /*AlertDialog dialog = new AlertDialog.Builder(this)
//             //.setTitle("AlerDialog")
//             .setMessage("")
//             //.setNegativeButton("",null)
//             .setPositiveButton("v",new DialogInterface.OnClickListener() {
//                 @Override
//                 public void onClick(DialogInterface dialog, int which) {
//                     n.size =  100;
//                 }
//             })
//             .setNegativeButton("z",new DialogInterface.OnClickListener() {
//                 @Override
//                 public void onClick(DialogInterface dialog, int which) {
//                     n.size = 0;
//                 }
//             })
//             .create();
//         dialog.show();*/
        
        
//         //启动游戏
//         AndroidApplicationConfiguration cfg = new AndroidApplicationConfiguration();

//         initialize(new MyGdxGame(), cfg);
    
//     }
    
//     /*@Override public void onWindowFocusChanged(boolean hasFocus) {
//         if (hasFocus && Build.VERSION.SDK_INT >= 19) {
//             View decorView = getWindow().getDecorView();
//             decorView.setSystemUiVisibility(
//                 View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//                 | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//                 | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                 | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                 | View.SYSTEM_UI_FLAG_FULLSCREEN
//                 | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
//         }
//     }*/
    
// }
