// package com.zyx.x;
// import com.badlogic.gdx.graphics.g2d.BitmapFont;
// import com.badlogic.gdx.Gdx;
// import com.badlogic.gdx.graphics.Color;

// public class mFont {

//     public static BitmapFont mainbitmapFont;

//     static{
//         mainbitmapFont = new BitmapFont(Gdx.files.internal("font/font-cn.fnt"),Gdx.files.internal("font/font-cn.png"),false);
//         mainbitmapFont.setColor(Color.GREEN);
//     }
// }

