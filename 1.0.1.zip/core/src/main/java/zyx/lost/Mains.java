// package zyx.lost;

// import com.badlogic.gdx.Gdx;
// import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
// import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;


// // Please note that on macOS your application needs to be started with the -XstartOnFirstThread JVM argument
// public class Mains {
//     public static void main (String[] arg) {
//         Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
//         config.useVsync(false);
//         //config.setIdleFPS(-1);
//        // config.set
//         //config.setForegroundFPS(-1);
//         config.setTitle("新项目");
//         config.setWindowSizeLimits(2400,1400,2400,1400);
//         //config.setWindowSizeLimits(2400/3,1400/3,2400,1400);
//         new Lwjgl3Application(new MyGdxGame(), config);
//         Gdx.graphics.setVSync(false);
//         //Gdx.graphics.setForegroundFPS(-1);
//     }
// }

// //shift + ctrl + p 打开命令
// //ctrl + f 查找替换