package zyx.lost.component;

public class TypingAnimaList {
    
    public static void init(){
        
    }
}
