package zyx.lost.entities;

public class Skill {
    
    
    
}