package zyx.lost.entities;

public class Bag {
    
    
    
}