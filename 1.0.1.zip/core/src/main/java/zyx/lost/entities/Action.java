package zyx.lost.entities;

public interface Action {
    
    void move();
    
}
