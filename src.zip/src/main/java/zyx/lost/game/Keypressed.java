package zyx.lost.game;
public abstract class  Keypressed{
    public abstract void key();
}