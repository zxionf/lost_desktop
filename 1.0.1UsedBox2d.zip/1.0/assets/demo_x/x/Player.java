// package com.zyx.x;

// public class Player {
//     public int camp;
    
//     public int hp;
//     public int ht;
    
//     public int mame;
    
//     public int x ,y;
    
    
// }
