// package com.zyx.x;
// import com.badlogic.gdx.Gdx;
// import com.badlogic.gdx.graphics.Texture;
// import com.badlogic.gdx.graphics.g2d.TextureRegion;
// import com.badlogic.gdx.scenes.scene2d.ui.Image;
// import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

// public class STING {
    
//     Image get(int s){
//         return new Image(new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("test"+s+".png")))));
        
//     }
    
// }

