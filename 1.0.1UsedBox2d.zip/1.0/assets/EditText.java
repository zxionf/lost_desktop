// package com.zyx.kga.lv;

// import com.badlogic.gdx.graphics.Pixmap;
// import com.badlogic.gdx.graphics.Texture;
// import com.badlogic.gdx.graphics.g2d.BitmapFont;
// import com.badlogic.gdx.scenes.scene2d.Stage;
// import com.badlogic.gdx.scenes.scene2d.ui.TextField;
// import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
// import com.badlogic.gdx.graphics.g2d.TextureRegion;
// import com.badlogic.gdx.utils.viewport.StretchViewport;
// import com.badlogic.gdx.Gdx;
// import com.badlogic.gdx.graphics.Color;

// public class EditText {

//     // 视口世界的宽高统使用 480 * 800, 并统一使用伸展视口（StretchViewport）
    

//     // 位图字体
//     private BitmapFont bitmapFont;



//     // 文本框（密码）
    

//     /**
//      * 创建文本框的背景纹理
//      */
    

//     public void create() {

//         // 使用伸展视口（StretchViewport）创建舞台
//         //stage = new Stage(new StretchViewport(WORLD_WIDTH, WORLD_HEIGHT));

//         /*
//          * 第 1 步: 创建文本框背景纹理, 光标纹理, 以及创建位图字体（用于显示文本框中的文本）
//          * 
//          * 为了方便演示, 这里创建纹理不再用图片来创建, 而是使用 Pixmap 来创建
//          */
        
//     }
	
// 	public String getText(){
// 		return edittext.getText();
// 	}

// }
