package zyx.lost.component;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import zyx.lost.Asst;

public class ZButton {


    public static class TextBtn extends TextButton {
        public TextBtn(String s, ClickListener c) {
            super(s, Asst.TextBtnStyle.getNormal());
            this.addListener(c);
		}
	}

}
