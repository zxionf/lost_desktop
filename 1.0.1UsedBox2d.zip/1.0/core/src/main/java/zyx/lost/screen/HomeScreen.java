package zyx.lost.screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import zyx.lost.I;
import zyx.lost.MyGdxGame;
import zyx.lost.component.ZButton;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.GL20;
import java.util.Random;

public class HomeScreen extends AbstractScreen {
	
	Stage stage = new Stage();
	ZButton.TextBtn startbtn;
	Label l;
	Batch batch = new SpriteBatch();
	BitmapFont font;
    
    
    int start = Integer.parseInt("4e00", 16);
    int end = Integer.parseInt("9fa5", 16);
    int i = start;
    
    int ii = 0;
	public HomeScreen(MyGdxGame game){
		super(game);
		Gdx.graphics.setForegroundFPS(30);
		Gdx.graphics.setVSync(false);
		
		startbtn = new ZButton.TextBtn("开始游戏",new ClickListener(){
                public void clicked(InputEvent event, float x, float y) {
                    //App.request_permissions();
                }
            });
		stage.addActor(startbtn);
		startbtn.setPosition(I.ScreenWidth/2,I.ScreenHeight/2);
		
		Label.LabelStyle ls = new Label.LabelStyle();
		ls.font = I.fontcy16x2;
		ls.font.setColor(Color.GREEN);
        ls.font.getData().setScale(16);
		l = new Label("游戏开始",ls);
		stage.addActor(l);
		l.setPosition(0,0);
        l.setSize(600,600);
		Gdx.input.setInputProcessor(stage);
		
		/*FreeTypeFontGenerator generator = new FreeTypeFontGenerator( Gdx.files.internal( "font/siyuanrouheiMonospaceRegular.ttf") );
		FreeTypeFontGenerator.FreeTypeFontParameter p = new FreeTypeFontGenerator.FreeTypeFontParameter();
		p.color = Color.BLACK;
		p.size = 60;
		font = generator.generateFont(p);*/
        
        font = I.fontcy16x2;
		
	}
	
	@Override
	public void show() {
	}

	@Override
	public void hide() {
	}

	@Override
	public void render(float p) {
        Gdx.gl.glClearColor(0, 0, 0, 0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
		stage.act();
		stage.draw();
		batch.begin();
        //if(i<=end)i++;
        
        ii++;
        if(ii==20){
            ii= 0;
            i++;
        }
        
        
        
		//I.fontc16.setColor(Color.GRAY);
		//I.fontc16.draw(batch,"开始游戏",600,600);
		//font.draw(batch,""+(char)i,I.ScreenWidth/3,I.ScreenHeight/2);
		l.setText(""+(char)i);
		
        batch.end();
	}

	@Override
	public void resize(int p, int p1) {
	}
	public int getintrand(int MIN,int MAX) {
        Random rand = new Random();
        //int MAX = 100, MIN = 1;
        return rand.nextInt(MAX - MIN + 1) + MIN;
    }
}
