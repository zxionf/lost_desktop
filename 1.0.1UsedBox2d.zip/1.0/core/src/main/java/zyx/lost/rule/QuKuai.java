package zyx.lost.rule;

import com.badlogic.gdx.math.Vector2;

public class QuKuai {
//[layer][x][y]
    public static final int qukuaisize = 64;
    public static final int x = 64;
    public static final int y = 64;
    public int[][][] blocks = new int[6][x][y];
    public Vector2[][][] jizhunxianglianng = new Vector2[2][5][5];
}
