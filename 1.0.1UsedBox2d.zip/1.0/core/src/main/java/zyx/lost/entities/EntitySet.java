package zyx.lost.entities;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Array;
import zyx.lost.GameManager;
import zyx.lost.component.InformationBar;

public class EntitySet {

    GameManager gm;
    World world;
    Stage stage;
    SpriteBatch batch;
    InformationBar ib;

    public static int zombie = 1 ;

    Array<Entity> arr = new Array<Entity>();

    public EntitySet(GameManager gm,World world,Stage stage,SpriteBatch batch,InformationBar ib){
        this.gm = gm;
        this.world = world;
        this.stage = stage;
        this.batch = batch;
        this.ib = ib;
    }

    /*public void create(int i){
        switch(i){
            case 1:
                Zombie zombie = new Zombie(world,stage,batch,ib);
                arr.add(zombie);
                break;
        }
    }*/

    public void update(){
        for(Entity e :arr){
            e.update();
        }
    }

    public void move(){
        for(Entity e :arr){
            e.move();
        }
    }
}

