// package com.zyx.x;
// import android.app.AlertDialog;
// import android.app.Activity;

// public class Dialog extends Activity{
    
//       void DiyDialog2() {
//         AlertDialog.Builder alterDiaglog = new AlertDialog.Builder(Dialog.this);
//         //alterDiaglog.setView(R.layout.dia);//加载进去
//         AlertDialog dialog = alterDiaglog.create();
//         //显示
//         dialog.show();
//         //自定义的东西
//     }
    
// }
